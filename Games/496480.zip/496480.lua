addappid(496480)
addappid(496481, 1, "1c6dccefec8ec716b2ff0f3dedfe4fc22df175ead8b8cc972958b1fb0b2dff75")
setManifestid(496481, "3260152830168437116", 0)