addappid(733050)
addappid(733051, 1, "9d7710ddc1da2c4079d49a7edecaefc631d4804bfa57ec1dbc9b3abcb0ccebcf")
setManifestid(733051, "4920676495861867353", 0)