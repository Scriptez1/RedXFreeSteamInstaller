addappid(1038620)
addappid(1038621, 1, "4588b7efacca1252df5ccc4cedf1bc1dec480ebe5a9fe5a79ab1fc7ca51cbc53")
setManifestid(1038621, "5169762982327172988", 0)