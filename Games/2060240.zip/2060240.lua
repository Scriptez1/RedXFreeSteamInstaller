addappid(2060240)
addappid(2060241, 1, "6225668ba7538cb3bcddeaaddcd65be5ae2dfd1aea28b4af83ea59ce042d2caf")
setManifestid(2060241, "1825767769592083003", 0)