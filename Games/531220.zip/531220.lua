addappid(531220)
addappid(531221, 1, "06ef5daabdb6b1db9f839accb671aef356b7ee90f33cbaa0a9a0df60e42d40c1")
setManifestid(531221, "2069778352179299501", 0)