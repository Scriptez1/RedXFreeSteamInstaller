-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 526870.lua
addappid(526870)
addappid(228988,0,"1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")
setManifestid(228988,"6645201662696499616")
addappid(526871,0,"ae0ab673da3c9d0f444b1cd61fe8f2235d43e6c0401684a78f4fbdfc8f0d9bc1")
setManifestid(526871,"4846844245916086222")