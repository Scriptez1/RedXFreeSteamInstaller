-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 2627260.lua
addappid(2627260)
addappid(2627261, 1, "1dbbfa4a1302ac713af5d572bd94e7d0708ba581ca184c4124588ff3fdc06481")
setManifestid(2627261, "4989820315570254152", 58644108257)
addappid(3717100)