addappid(2878960)
setManifestid(228989,"550968249685141759")
addappid(2878961,0,"06400ef21bacfd625a917c8964e13740059333d2173dc2496357ef23db97f483")
setManifestid(2878961,"9171456634258760117")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]