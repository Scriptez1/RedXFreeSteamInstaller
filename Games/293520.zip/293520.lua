addappid(293520)
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(293521,0,"a9c628e41963792f4531685616b694e2298bcbf220ea887acf723a47bd444997")
setManifestid(293521,"1019983725065875710")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]