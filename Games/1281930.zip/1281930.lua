addappid(1281930)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(1281932,0,"5385c2c3b4d8b9e7365f5679ddb90c26af9660fb624768d2fba141b46cf58ec8")
addappid(1281933,0,"ace4929293e347c514440fb664ba011219611629c187e7d79d5656eaadc70e82")
addappid(1281934,0,"c1d827072fb6ba28cd0eb5de52b3f9ae84506edacbdcb8c0e006c28ee27338fe")
addappid(1281931,0,"2f3d1de6d30d21aef8361e268a82c2b030971620d9ae0611ca452d04d3db8481")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]