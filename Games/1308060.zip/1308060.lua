addappid(1308060)
addappid(1308061, 1, "1fb5ac3ca867fac728dc958b95ecb7c5ffa237d68d9fabb8bfdbe13e0a4ed6f0")
setManifestid(1308061, "9054073483451168868", 0)