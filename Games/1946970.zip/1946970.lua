addappid(1946970)
addappid(1946972, 1, "c0b4ac6afa828ede1090412d7e19d3bef2addecfdc3f6e2d6d03dc7f5deff54e")
setManifestid(1946972, "3900700366105062659", 0)