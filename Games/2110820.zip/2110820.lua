addappid(2110820)
addappid(2110821, 1, "917826f8e3f15caeaeaeac968cabcaf30fdba21f7cf0a47111a2f6ccfe178329")
setManifestid(2110821, "4049271790250262677", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]