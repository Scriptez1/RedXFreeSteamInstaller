addappid(65740)
addappid(65741, 1, "f2ee6b8bee0d04aeba49e7db9a3b15b5abe19fee53a1698c75c6c7b5aac44e7a")
setManifestid(65741, "3056760075593311069", 0)