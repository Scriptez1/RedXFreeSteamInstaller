addappid(7650)
addappid(7651, 1, "7dac116ddfe0ab3e06866b2a6dfffd44d546fac5d9f1c90a0068ee4a90aad536")
setManifestid(7651, "6404583407423913008", 0)