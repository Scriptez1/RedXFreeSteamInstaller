addappid(21970)
addappid(21971, 1, "e704dbef4f4282016b56efda28a5b9defecd3c92b4693419452e48342779da66")
setManifestid(21971, "5246609984688734642", 0)
addappid(21972, 1, "ee735b0ecf542d1fc838ad6d5bd4c961b78e0e5012a86fb7e8091ceef0146585")
setManifestid(21972, "7828516888385125704", 0)
addappid(21995, 1, "53aa6bccae73a0277e964309643e1fd3a33f05c9b6a39df0ed35d43effa80cd2")
setManifestid(21995, "7464603070576329608", 0)
addappid(21996, 1, "6e52e24afa5dfcfe1a5139433c950e457139f5fe2bf954e7c538329976e15768")
setManifestid(21996, "1520678601774659923", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]