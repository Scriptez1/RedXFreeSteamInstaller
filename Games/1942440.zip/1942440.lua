addappid(1942440)
addappid(1942441, 1, "8ddd156bd3bf1ab85224bdb5e8f57c9b9ecb0c0a86105b5bc61fcfaabbd7c5e3")
setManifestid(1942441, "90580496883576099", 0)