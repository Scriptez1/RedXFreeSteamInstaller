addappid(312610)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(312611,0,"7f1d0f535b6ae360297a32d8be65cde7b69860a123f019983d3b56e37933df8a")
setManifestid(312611,"3206672683359619399")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]