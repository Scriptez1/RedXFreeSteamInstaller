addappid(260230)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(260231,0,"6c41bd4691a0b3d82697e2b41689bb5b94b99f6d250f162227b1cd98bd902c4a")
setManifestid(260231,"4720306033921821350")
addappid(260232)
addappid(406181)
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
setManifestid(1716751,"3341282173115166582")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]