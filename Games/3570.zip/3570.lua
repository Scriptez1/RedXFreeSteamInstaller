addappid(3570)
addappid(3571, 1, "a5767c7daca496aadcbad5a155f462ad604a1ef0b8bf622a68c656fc02aa7f35")
setManifestid(3571, "3504622786977710234", 0)