addappid(205270)
addappid(205271, 1, "ba70ce8d3d2ad57b7a5ef0fdf9fec360dc1b5a473bb8b2de5f57dd8e1edc1ab2")
setManifestid(205271, "6971411101558029279", 0)