addappid(3180150)
addappid(3180151, 1, "28de3e0bee2c6383e918f4f8ce53cb834444d8015c34213ea29b92874b5c884e")
setManifestid(3180151, "2295287205462411578", 1620040315)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/farestopp 
]]