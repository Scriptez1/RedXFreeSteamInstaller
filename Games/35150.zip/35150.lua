addappid(35150)
addappid(35133, 1, "29d597bafb55aad4f38fe00ecdababd9a7131cf1d9f82dd27c1ea0d930f7960d")
setManifestid(35133, "3784295842485571982", 0)