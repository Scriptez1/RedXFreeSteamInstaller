addappid(412480)
addappid(412481, 1, "edb4fc97ecc0f4c06bf7bede4e5388fc7cbecfd6baa038a26d03d7b4cd1991f1")
setManifestid(412481, "7607762575207225656", 0)