addappid(698760)
addappid(698760, 1, "135cad5de69db82c1ea9e4f6f0a0afb4159dc0ae2fc52f8e5e87ddb88faaee68")
setManifestid(698760, "2488799774289273554", 0)