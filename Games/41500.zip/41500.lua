addappid(41500)
addappid(41501,0,"6236391020c0136f5aa7550ae18794ff0dce37186d0c94240d2ff1bb6472f889")
setManifestid(41501,"907749400291796896")
addappid(41503,0,"7c0d23ea8df78c942a0ed2ecbaa432a9eff811030a35e98ddf4c32200497b97d")
setManifestid(41503,"5133555216298001494")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]