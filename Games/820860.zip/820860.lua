addappid(820860)
addappid(820860, 1, "fea4b8381cad3c59ba4a6aaae1eee9f48df7822ef15ce2f0b21e3fab485ca1bf")
setManifestid(820860, "5389986755859243877", 0)