addappid(372960)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(372961,0,"2eae495bbc866ad7a2b5c4c8cf5f0610c618504bea06cdb03b9134c1f5f079a6")
setManifestid(372961,"902042437144508443")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]