addappid(2290180)
addappid(2290181, 1, "87bb928cf12682614e38b33c1fdbcfe71c6473b5bad0c278583e2478ccf34f36")
setManifestid(2290181, "3648917569702865508", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]