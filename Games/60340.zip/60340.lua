addappid(60340)
addappid(60341, 1, "9c40dfd43c8cfe8b7266addc9bedf4ae255469fa028ba0c1ee1386db29dc2bde")
setManifestid(60341, "3320146169388340234", 0)