addappid(1055090)
addappid(1055091, 1, "66d304c52dd7f4be0c45fde9dfeeccb0dc1449ce3e6dc21bb37ca0bd1b37aaeb")
setManifestid(1055091, "6328394867138435433", 0)