addappid(1341640)
addappid(1341641, 1, "0dddd7ad2e70dc9dbafe959ff89b01ceed88ad00fd165a5eed236bcf564dc4c4")
setManifestid(1341641, "5947118773181093624", 0)