addappid(756680)
addappid(756681, 1, "2f9eb1daa55a190dcc8fbaf53decba7da5bd3df4f88ef2cad5e82cc49fef1581")
setManifestid(756681, "687259209636910559", 0)