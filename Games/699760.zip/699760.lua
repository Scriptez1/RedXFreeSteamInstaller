addappid(699760)
addappid(699761, 1, "5bac96d92bb3cc6c63ac7eb3ef3a3a3c370c29cc5d4c8e70f02d1b84efeffcfb")
setManifestid(699761, "6274885390247924033", 0)