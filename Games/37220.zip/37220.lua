addappid(37220)
addappid(37221, 1, "f4fb1b41b5fc134b9f6df39f6cbafec576ecadd47d1bf6c2ba5a19e076dc62a6")
setManifestid(37221, "3816096595183704753", 0)