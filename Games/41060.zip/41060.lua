addappid(41060)
addappid(41061,0,"f0f57c2acd45a567b57dc6ff1cd9943704c5c96c24eb4484d8d5772c25937bfe")
setManifestid(41061,"480714688252871483")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]