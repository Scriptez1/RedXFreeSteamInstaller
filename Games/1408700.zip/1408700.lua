-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 1408700.lua
addappid(1408700)
addappid(1408701,0,"21d4025d74bf53f1ad32e88d081f27989541ccfd401620152490b8706ff36fd6")
setManifestid(1408701,"7021599558107969767")