addappid(293760)
setManifestid(228985,"3966345552745568756")
setManifestid(228988,"6645201662696499616")
setManifestid(228990,"1829726630299308803")
setManifestid(229006,"1784011429307107530")
addappid(293761,0,"fb8222a3b3e27287488f679bac5fcfad63a0e0788aba25dc92daef1b8bcc8a20")
setManifestid(293761,"7501038797786243617")
addappid(359180,0,"ed26582ba2f857a7988fddd419b3349a3ea2c59cea1259d7f6d52383e1fd9252")
setManifestid(359180,"2123245250755802066")
--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]
