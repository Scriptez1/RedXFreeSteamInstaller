addappid(1036116)
addappid(1036116, 1, "5329c1bd21838abf22c54f013bcfe74a0fb9acc1ce05b4babefc5ccadbcb39ba")
setManifestid(1036116, "5279125816228455875", 0)