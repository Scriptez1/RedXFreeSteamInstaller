addappid(263280)
addappid(263281,0,"3585d18682ade52fa9221944b2d43b37a7455cad1c90773fe1b189516f1e71b0")
addappid(1346080,0,"f544985a1aad2dadc773473f41ad348fdeaee887b3254a3e43832c3ac7d43832")
setManifestid(263281,"4994964581084626803")
setManifestid(1346080,"3573886823066846954")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]