addappid(416590)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(416591,0,"f09af4d91921b55b9d09a8f5229f160bc15a5a8fe5519530bc3a189ebff3f4f6")
setManifestid(416591,"6617663879432030817")
addappid(416592,0,"ff0edb25ef7a3e95ad74617cff7ae05f5075bf31f5aee48a6ce44231df04d52e")
setManifestid(416592,"5143410964361361769")
addappid(416593,0,"f0680f777e95ba8269e291593b01da2e83a1395c42ca6499169b243077506932")
setManifestid(416593,"3333370870162049351")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]