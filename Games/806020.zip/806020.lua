addappid(806020)
addappid(806021, 1, "dfd5d27483457af5c4d0f0c6dd0de91fa5e9cf9987bbaf7db0bd8ed3ce734fa5")
setManifestid(806021, "841607787524985241", 0)