-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 949230.lua
addappid(949230)
setManifestid(228988,"6645201662696499616")
setManifestid(228989,"3514306556860204959")
addappid(949231,0,"eadf0796a624164bd8838fc14a95bd34b9c41e87048bbb4a23b86f0b77c1fb67")
setManifestid(949231,"1955942157688491127")