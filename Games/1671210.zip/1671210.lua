addappid(1671210)
addappid(1671212,0,"d3b68663ee177c37ee1d5cb49de06cbf9d0d81b2b72ffdde18665f6db6c6ed9f")
setManifestid(1671212,"6530852604090871226")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]