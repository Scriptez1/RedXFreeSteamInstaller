addappid(272330)
addappid(272331, 1, "5bef8862a9c22bab9ca56c52fecbdf8bffd9be8515e8add0ce07f31b7d555d30")
setManifestid(272331, "803046887210967057", 0)
addappid(354270, 1, "909c9ed9b1a33d2ed7adafeede93ec7e9ad92eb654e2ee64249be8717ed9d0e7")